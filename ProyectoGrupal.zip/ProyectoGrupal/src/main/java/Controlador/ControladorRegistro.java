package Controlador;

import Modelo.Paciente;
import Modelo.Doctor; // Asegúrate de tener esta importación si tienes la clase Doctor
import Vista.Registrarse;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

public class ControladorRegistro {

    private Registrarse vista;
    private Paciente paciente;
    private Doctor doctor; // Añadido para manejar la instancia de Doctor
    private ConexionBD conexion;

    public ControladorRegistro() {
        vista = new Registrarse();
        vista.setVisible(true);
        initializeListeners();
        Mensajes("");
    }

    private void initializeListeners() {
        vista.BtnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Registro();
            }
        });
        vista.BtnRegresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorLogin controlador= new ControladorLogin();
                vista.dispose(); 
            }
        });
        vista.BtnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public void Mensajes(String mensaje) {
        vista.LbNom.setText(mensaje);
        vista.LbApe.setText(mensaje);
        vista.LbSino.setText(mensaje);
        vista.LbDocPaci.setText(mensaje);
        vista.LbCedu.setText(mensaje);
        vista.LbContra.setText(mensaje);
        vista.LbCelu.setText(mensaje);
        vista.LbFechaNaci.setText(mensaje);
    }

    public boolean validaciones(String nombre, String apellido, String cedula, String celular, String contrasenia, String fechaNacimiento) {
        boolean esValido = true;

        // Validar nombre
        if (nombre.isEmpty()) {
            vista.LbNom.setText("Falta completar");
            esValido = false;
        } else if (!nombre.matches("[a-zA-Z]{1,50}")) {
            vista.LbNom.setText("Nombre inválido (solo letras)");
            esValido = false;
        } else {
            vista.LbNom.setText("");
        }

        // Validar apellido
        if (apellido.isEmpty()) {
            vista.LbApe.setText("Falta completar");
            esValido = false;
        } else if (!apellido.matches("[a-zA-Z]{1,50}")) {
            vista.LbApe.setText("Apellido inválido (solo letras)");
            esValido = false;
        } else {
            vista.LbApe.setText("");
        }

        // Validar cédula
        if (cedula.isEmpty()) {
            vista.LbCedu.setText("Falta completar");
            esValido = false;
        } else if (!cedula.matches("\\d{10}")) {
            vista.LbCedu.setText("Cédula inválida (10 dígitos, solo números)");
            esValido = false;
        } else {
            vista.LbCedu.setText("");
        }

        // Validar celular
        if (celular.isEmpty()) {
            vista.LbCelu.setText("Falta completar");
            esValido = false;
        } else if (!celular.matches("\\d{10}")) {
            vista.LbCelu.setText("Número de celular inválido (10 dígitos, solo números)");
            esValido = false;
        } else {
            vista.LbCelu.setText("");
        }

        // Validar contraseña
        if (contrasenia.isEmpty()) {
            vista.LbContra.setText("Falta completar");
            esValido = false;
        } else {
            vista.LbContra.setText("");
        }

        // Validar fecha de nacimiento
        if (fechaNacimiento.isEmpty()) {
            vista.LbFechaNaci.setText("Falta completar");
            esValido = false;
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
            sdf.setLenient(false);
            try {
                sdf.parse(fechaNacimiento);
                vista.LbFechaNaci.setText("");
            } catch (ParseException e) {
                vista.LbFechaNaci.setText("Fecha de nacimiento inválida (formato: AAAA/MM/ DD)");
                esValido = false;
            }
        }

        // Validar selección de Doctor/Paciente
        if (!vista.RbDoctor.isSelected() && !vista.RbPaciente.isSelected()) {
            vista.LbDocPaci.setText("Seleccionar una opción");
            esValido = false;
        } else {
            vista.LbDocPaci.setText("");
        }

        // Validar selección de Sí/No
        if (!vista.Rbsi.isSelected() && !vista.Rbno.isSelected()) {
            vista.LbSino.setText("Seleccionar una opción");
            esValido = false;
        } else {
            vista.LbSino.setText("");
        }

        return esValido;
    }

    public void Registro() {
        String nombre = vista.TxtNom.getText();
        String apellido = vista.TxtApe.getText();
        String cedula = vista.TxtCedu.getText();
        String celular = vista.TxtCelu.getText();
        String contrasenia = vista.TxtContra.getText();
        String fechaNacimiento = vista.TxtFechaNa.getText();
        String tipo = vista.RbDoctor.isSelected() ? "Doctor" : "Paciente";
        String seguro = vista.Rbsi.isSelected() ? "Si" : "No";

        if (validaciones(nombre, apellido, cedula, celular, contrasenia, fechaNacimiento)) {
            if (tipo.equals("Paciente")) {
                // Solicitar número de emergencia
                String numeroEmergencia = JOptionPane.showInputDialog(vista, "Ingrese número de emergencia:");
                if (numeroEmergencia == null || !numeroEmergencia.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(vista, "Número de emergencia inválido (10 dígitos, solo números)");
                    return;
                }
                paciente = new Paciente(numeroEmergencia, "", nombre, apellido, cedula, celular, contrasenia, fechaNacimiento, seguro);
                conexion = new ConexionBD("GestorDeCitasMedicas", "Paciente");
                conexion.RegistroUsuario(numeroEmergencia, cedula, nombre, apellido, celular, contrasenia, fechaNacimiento, seguro);
                JOptionPane.showMessageDialog(vista, "Registro de paciente exitoso");
            } else if (tipo.equals("Doctor")) {
                // Solicitar especialidad
                String[] especialidades = {"Odontología", "Medicina General", "Psicología"};
                String especialidad = (String) JOptionPane.showInputDialog(vista, "Seleccione especialidad:", "Especialidad", JOptionPane.QUESTION_MESSAGE, null, especialidades, especialidades[0]);
                if (especialidad == null) {
                    JOptionPane.showMessageDialog(vista, "Debe seleccionar una especialidad");
                    return;
                }
                doctor = new Doctor(nombre, apellido, cedula, celular, contrasenia, fechaNacimiento, seguro, especialidad);
                conexion = new ConexionBD("GestorDeCitasMedicas", "Doctor");
                conexion.RegistroDoctor(especialidad, cedula, nombre, apellido, celular, contrasenia, fechaNacimiento, seguro);
                JOptionPane.showMessageDialog(vista, "Registro de doctor exitoso");
            }
        } 
    }
}
