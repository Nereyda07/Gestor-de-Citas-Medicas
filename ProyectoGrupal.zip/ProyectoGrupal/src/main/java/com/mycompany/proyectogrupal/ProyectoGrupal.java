/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectogrupal;

import Controlador.ControladorRegistro;

/**
 *
 * @author Det-Pc
 */
public class ProyectoGrupal {

    public static void main(String[] args) {
        ControladorRegistro inicio=new ControladorRegistro();
    }
}
